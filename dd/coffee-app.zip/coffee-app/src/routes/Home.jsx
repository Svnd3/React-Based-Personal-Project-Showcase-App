import { Link } from "react-router-dom";
import { useProductContext } from "../context/ProductContext.jsx";

export default function Home() {
  const { storeInfo, allProducts, loading, error } = useProductContext();

  return (
    <section className="home-page" data-testid="home-page">

      {/* ── Hero ── */}
      <section className="hero-section">
        <div className="hero-copy">
          <span className="eyebrow">☕ Admin Landing Page</span>
          <h1>{storeInfo?.name ?? "Coffee R Us"}</h1>
          <p>
            {storeInfo?.description ??
              "The go-to store for craft coffee and elegant gifts."}
          </p>

          <div className="hero-stats">
            <div className="stat-card">
              <small>Products</small>
              <strong>{allProducts.length}</strong>
            </div>
            <div className="stat-card">
              <small>Phone</small>
              <span className="stat-phone">
                {storeInfo?.phone_number ?? "555-555-5555"}
              </span>
            </div>
          </div>

          <div className="hero-actions">
            <Link to="/shop" className="primary-button">
              Explore Collection
            </Link>
            <Link to="/admin" className="ghost-button">
              Open Admin
            </Link>
          </div>
        </div>

        {/* ── Right: featured workflow ── */}
        <div className="hero-box">
          <h3>Featured workflow</h3>
          {[
            "Preview products with live search",
            "Add new items from the admin portal",
            "Edit pricing and inventory details",
            "Delete discontinued products",
          ].map((item) => (
            <div key={item} className="workflow-item">
              <span className="workflow-dot" />
              {item}
            </div>
          ))}
        </div>
      </section>

      {/* ── How it works ── */}
      <section className="how-section">
        <h2>How this portal works</h2>

        {loading ? (
          <p style={{ color: "var(--muted)", marginTop: "1rem" }}>
            Loading…
          </p>
        ) : error ? (
          <p className="error-text">{error}</p>
        ) : (
          <div className="how-grid">
            <div className="how-card">
              <div className="how-icon">🔀</div>
              <h4>Client-side routing</h4>
              <p>
                Navigate between home, shop, and the admin portal without
                page refreshes.
              </p>
            </div>
            <div className="how-card">
              <div className="how-icon">🔄</div>
              <h4>State management</h4>
              <p>
                A shared React context keeps search, products, and edits in
                sync.
              </p>
            </div>
            <div className="how-card">
              <div className="how-icon">💾</div>
              <h4>Backend persistence</h4>
              <p>
                Mocked JSON backend stores products and responds to CRUD
                actions.
              </p>
            </div>
          </div>
        )}
      </section>
    </section>
  );
}
